import React, { useState } from 'react';

export default function TerminalEmpleado() {
  // Simulando los datos que llegarían de ProductoRepository
  const [ticket, setTicket] = useState([]);

  return (
    <div className="flex h-screen bg-gray-50 font-sans">
      
      {/* Sección Izquierda: Catálogo de Ropa */}
      <div className="w-2/3 p-6 overflow-y-auto">
        <header className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-brand-dark">Terminal POS - Ropa</h1>
          <div className="text-brand-teal font-semibold">Empleado: Juan Pérez</div>
        </header>

        <div className="grid grid-cols-3 gap-6">
          {/* Tarjeta de Producto de ejemplo */}
          <div className="bg-white rounded-xl shadow-sm border border-brand-light p-4 hover:shadow-md transition">
            <div className="h-32 bg-brand-light rounded-lg mb-4 flex items-center justify-center text-brand-dark">
              [Imagen Chamarra]
            </div>
            <h3 className="font-bold text-brand-dark">Chamarra de Mezclilla</h3>
            <p className="text-sm text-gray-500 mb-4">Talla: M</p>
            <div className="flex justify-between items-center">
              <span className="font-bold text-brand-teal">$850.00</span>
              <button className="bg-brand-dark text-white px-3 py-1 rounded hover:bg-brand-teal transition">
                + Agregar
              </button>
            </div>
          </div>
          {/* ... más productos ... */}
        </div>
      </div>

      {/* Sección Derecha: Ticket / DetalleTicket */}
      <div className="w-1/3 bg-brand-light p-6 shadow-l flex flex-col">
        <h2 className="text-2xl font-bold text-brand-dark mb-6">Ticket Actual</h2>
        
        <div className="flex-1 overflow-y-auto">
          {/* Aquí iterarías sobre tu DetalleTicketDto */}
          <div className="flex justify-between items-center bg-white p-3 rounded-lg mb-2 shadow-sm">
            <div>
              <p className="font-semibold text-brand-dark">Chamarra de Mezclilla</p>
              <p className="text-xs text-gray-500">1 x $850.00</p>
            </div>
            <span className="text-brand-teal font-bold">$850.00</span>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t-2 border-brand-teal">
          <div className="flex justify-between text-xl font-bold text-brand-dark mb-6">
            <span>Total:</span>
            <span>$850.00</span>
          </div>
          
          {/* Botón de Pago que llamará al PaymentController con criptografía */}
          <button className="w-full bg-brand-primary text-white text-xl font-bold py-4 rounded-xl hover:bg-brand-accent hover:text-brand-dark transition duration-300 shadow-lg">
            Procesar Pago Seguro
          </button>
        </div>
      </div>

    </div>
  );
}